pallink
Palworld幻兽帕鲁，内网开服工具 后续功能：Pallink之间云存档同步，反外挂


联系： 
抖音：渣渣猫（不和吃螺蛳粉的人做朋友） 
tiktok：zhazhamao

介绍： PallinkService是一款应用于【幻兽帕鲁】游戏服务端的内网映射工具，使用本工具，可以使远程的游戏客户端连接到本地游戏服务端。

详细介绍： http://down.24992499.xyz/

使用方法：

步骤一：（有独立IP的跳到步骤二） 登录你拨号上网的设备（光猫、路由器），找到【端口转发】，找到【DMZ】，指向你使用游戏服务端那台电脑的IP。

步骤二： 启动游戏服务端。

步骤三： 启动PallinkService， 等待验证信息，直到出现”PallinkService running“， 向上一行，ServiceIP: xxx.xxx.xx.xx:9058 就是你可以外网连接的IP地址，左键拖动选择IP地址，右键复制。

步骤四： 发送IP给你的小伙伴，就可以一起游戏了。

guid=D7B65860B23334C08B67F7BD03E06FDC 
userver_ip=139.9.135.240
userver_port=9000