Pallink
Palworld's phantasmal creature Palu, intranet server opening tool.Upcoming features: Cloud save synchronization between Pallinks, anti-cheating measures.

Contact:
Douyin: tiktok：渣渣猫（不和吃螺蛳粉的人做朋友）
TikTok: zhazhamao

Introduction:PallinkService is an intranet mapping tool for the gaming server of [Palworld's phantasmal creature Palu]. Using this tool, remote game clients can connect to a local game server.

                                                                                                
Detailed introduction:http://down.24992499.xyz/
                                                                                                
Usage:
Step one: (If you have a dedicated IP, skip to step two)Log in to your dial-up internet device (optical modem, router), find [Port Forwarding], find [DMZ], and direct it to the IP of the computer you use for the game server.
Step two:Start the game server.
Step three:Start PallinkService,Wait for the verification information until "PallinkService running" appears,Above that line, ServiceIP: xxx.xxx.xx.xx:9058That is the IP address you can connect to from the external network. Drag to select the IP address with the left mouse button and right-click to copy.
Step four:Send the IP to your friends, and you can play together.

guid=D7B65860B23334C08B67F7BD03E06FD
Cuserver_ip=139.9.135.240
userver_port=9000